package com.example.prueba2get;

import androidx.appcompat.app.AppCompatActivity;

import java.util.concurrent.TimeUnit;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {
    public static final String USER_NAME = "0", SERVER_HOST = "1";
    private RequestQueue queue;
    private String host, user, password;
    private Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        queue = Volley.newRequestQueue(this);
    }

    public void sendMessage(View view) {
        EditText editText = findViewById(R.id.editTextTextHost);
        EditText editText1 = findViewById(R.id.editTextTextPersonName);
        EditText editText2 = findViewById(R.id.editTextTextPassword);

        host = editText.getText().toString();
        user = editText1.getText().toString();
        password = editText2.getText().toString();
        intent = new Intent(this, QuerysActivity.class);
        getData();
    }

    private void getData(){

        String url = "http://"+host+"/students?uid="+password;

        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                JSONObject oneObject;
                try {
                    oneObject = response.getJSONObject(0);
                    String oneObjectsItem = oneObject.getString("nom");
                    if(oneObjectsItem.equals(user) ){
                        // Es fa un putExtra del nom i host per treballar amb ells a la seguent Activity
                        intent.putExtra(USER_NAME, user);
                        intent.putExtra(SERVER_HOST, "http://"+host+"/");
                        startActivity(intent);

                    }else if (oneObjectsItem != user){
                        // Mal identificat
                        Toast.makeText(MainActivity.this,"Wrong user, try again!", Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    Toast.makeText(MainActivity.this,"Wrong password, try again!", Toast.LENGTH_SHORT).show();
                }
            }
        },
                new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
            }
        });
        queue.add(request);
    }
}