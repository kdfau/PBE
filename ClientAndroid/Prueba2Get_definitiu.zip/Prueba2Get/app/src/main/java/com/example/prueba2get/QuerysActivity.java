package com.example.prueba2get;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class QuerysActivity extends AppCompatActivity {

    private String host;
    private RequestQueue queue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_querys);

        queue = Volley.newRequestQueue(this);

        // Get the Intent that started this activity and extract the string
        Intent intent = getIntent();
        String nom = intent.getStringExtra(MainActivity.USER_NAME);
        host = intent.getStringExtra(MainActivity.SERVER_HOST);

        // Capture the layout's TextView and set the string as its text
        TextView textView = findViewById(R.id.textView2);
        textView.setText(nom);
    }

    public void logOut(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void checkQuery(View view) {
        EditText editQuery = (EditText) findViewById(R.id.etQuery);
        String query=editQuery.getText().toString(),  fullQuery= host+query;
        // COMPROBAR CAS TIMETABLES, MARKS O TASKS
        TextView textView = findViewById(R.id.textView3);
        if(query.contains("?")){
            String[] taula = query.split("\\?");
            textView.setText(taula[0]);
        }else{
            textView.setText(query);
        }
        sendQuery(fullQuery);
    }

    public void sendQuery(String fullQuery){
        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, fullQuery, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                try {
                    addTable(response);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        },
        new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(QuerysActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
            }
        });
        queue.add(request);
    }
    
    public void addTable(JSONArray response) throws JSONException {
        // Accedim a la taula
        TableLayout stk=(TableLayout) findViewById(R.id.table_main);
        //Establim que les columnes es puguin eixamplar
        stk.setStretchAllColumns(true);
        // Borrem la informació de dins la taula (si n'hi ha)
        stk.removeAllViews();

        String[] aux;
        ArrayList<String> nom = new ArrayList<String>();
        String[] prova = response.getJSONObject(0).toString().split("\\}");

        //Fem parsing per obtenir els noms de les columnes
        prova[0] = prova[0].replaceAll("\"|\\[|\\{", "");
        prova = prova[0].split("\\,");
        for(int i = 0; i < prova.length; i++){
            aux = prova[i].split("\\:");
            nom.add(aux[0]);
        }

        //Creem la primera fila
        TableRow tbrow0 = new TableRow(this);
        tbrow0.setBackgroundColor(Color.argb(255, 255, 155, 155));

                for (int i =0; i<nom.size();i++){
                    TextView tv = new TextView(this);
                    tv.setText(" "+nom.get(i)+" ");
                    tv.setGravity(Gravity.CENTER);
                    tv.setTextColor(Color.BLACK);
                    tbrow0.addView(tv);
                }
                stk.addView(tbrow0);

                //Creem files per introduir la informació
                for (int i=0; i < response.length(); i++){
                    String oneObject = response.getJSONObject(i).toString();
                    // TREBALLAR AMB ONEOBJECT PER ENSENYAR TOTA LA INFO
                    TableRow tbrow= new TableRow(this);
                    tbrow.setBackgroundColor(Color.argb(255, 194, 253, 224));

                    oneObject = oneObject.replaceAll("\"|\\{|\\}","");
                    String[] pairs = oneObject.split("\\,");

                    for (int j=0; j<pairs.length; j++){
                        String[] value = pairs[j].split("\\:",2);
                        TextView t1v = new TextView(this);
                        t1v.setText(value[1]);
                        t1v.setGravity(Gravity.CENTER);
                        t1v.setTextColor(Color.BLACK);
                        tbrow.addView(t1v);
                    }
                    stk.addView(tbrow);
        }
    }
}