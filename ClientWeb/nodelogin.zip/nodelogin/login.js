var mysql = require('mysql');
var express = require('express');
var session = require('express-session');
var bodyParser = require('body-parser');
var path = require('path');
var engines = require('consolidate');

var connection = mysql.createConnection({
	host     : 'localhost',
	user     : 'root',
	password : 'Queralt1998.',
	database : 'bd_CDR',
	port: '3306'
});

connection.connect(function(error){
    if(error){
       console.log(error);
    }else{
       console.log('Conexion correcta.');
    }
});

var app = express();
app.use(session({
	secret: 'secret',
	resave: true,
	saveUninitialized: true
}));
app.use(express.urlencoded({extended : true}));
app.use(express.json());

app.engine('html', engines.mustache);
app.set('view engine', 'html');

connection.on('err', function(err) {
	console.log("[mysql err]",err);
  });

app.get('/', function(request, response) {
	response.sendFile(path.join(__dirname + '/login.html'));
});

app.post('/auth', async(request, response) =>{
	var uid = request.body.uid;
	var nom = request.body.nom;
	if (uid && nom) {
		try{
			let result = await connection.query('SELECT nom, uid FROM Students;', function (err, result, fields)  {
			var suid = result[0].uid;
			var snom = result[0].nom;
			if(result[0] != null){
				if (result[0].uid === uid)  {
					request.session.loggedin = true;
					request.session.nom = result[0].nom;
					return response.redirect('/mainpage');
				} else {
					response.send('Incorrect Username and/or Password!');	
				}	
			}		
			});
		} catch(e) {
			console.log(e);
			response.redirect('/')
		}
	} else {
		response.send('Please enter Username and Password!');
	}
});

app.get('/mainpage', function(request, response) {
	if (request.session.loggedin) {
		response.render(__dirname + '/mainpage.html');
	} else {
		response.send('Please login to view this page!');
	}
	response.end();
});

app.listen(3000);